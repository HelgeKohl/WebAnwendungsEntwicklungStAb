Installieren:
npm install

Starten:
debug: npm run debug
production: npm run start